[SOP]
Windows flash: Please click "ZRQ_228.exe" to update bios.